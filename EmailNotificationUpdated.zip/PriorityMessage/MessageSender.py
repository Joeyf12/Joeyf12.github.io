import notify2
from MessageSender import message