import checkMail
import ctypes

#ctypes.windll.user32.MessageBoxW(0, checkMail.eSubject, 'Priority Ticket Received', 0)

'''if checkMail.eDate == checkMail.today:
    # print('GOTTEM')
    # print(eDate)

    if checkMail.eSubject:'''

