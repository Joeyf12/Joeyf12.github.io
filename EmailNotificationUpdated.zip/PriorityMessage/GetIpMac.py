import checkMail


def user():
    checkMail.user


def password():
    checkMail.password
