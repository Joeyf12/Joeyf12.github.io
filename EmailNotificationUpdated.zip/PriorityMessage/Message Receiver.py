import os
import socket
import platform, re, uuid, json
import MessageSender
import GetIpMac

print (GetIpMac)

host = ""
port = 13000
buf = 1024
address = (host, port)
