import json
import pymongo
from pip._vendor.distlib.compat import raw_input
from pymongo import MongoClient

'''
Mongodb Server User and Pass:
User: dbAdmin
Pass: NULYXv3GydQckWF
IP: 71.230.125.87'''

uri = "mongodb://127.0.0.1:27017"
# Connect to the mongo database using database user and password
client = pymongo.MongoClient("mongodb+srv://dbAdmin:NULYXv3GydQckWF@cs-499-jv2qk.mongodb.net/test?retryWrites=true&w"
                             "=majority")

# Connect to the database and specify the collection
database = client['client']
print(database)

# Access the inspections database in the Mongodb
collection = database['inspections']
print(collection)

# Variable to locate documents in the collection
Documents = collection.find({})

# Print statement to confirm program is able to access documents in Mongo
'''for address in Documents:
    print(Documents)'''

# Print Statement to guide user through menus
selection = input("Select 1 to insert, Select 2 to Read, Select 3 to Update, Select 4 to Delete, or 0 to exit")

# Syntax to test inserting document in the Mongo Database
# database.inspections.insert_one({ "State": "New York"})


def insert():
    try:
        print("Enter 0 to exit")
        docu = input("Enter document title eg: State, Street Name, Street Number")
        file = input("Enter New File eg: New York, Wyona St, 206")
        if docu:
            database.inspections.insert_one({
                docu: file
            })
            print("Added Successfully")

        elif '0':
            exit()

    except Exception:
        print("Error encountered")


def read():
    try:
        docuName = database.inspections.find().limit(10)
        print('\n All data from the inspections database \n')
        for name in docuName:
            print(name)

    except Exception:
        print("Error Encountered")

def update():
    try:
        docuList = database.inspecitons.find()
        print(docuList)
        docuUpdate = raw_input("Enter document to update")


    except Exception:
        print("Error Encountered")


def delete():
    try:
        print("Enter 0 to exit")
        docuDel = raw_input("Enter Document to Delete eg: State, Street Name, stNum")
        fileDel = raw_input("Enter File to Delete eg: New York, Wyona St, 206")

        if docuDel:
            database.inspections.delete_one({
                docuDel: fileDel
            })
            print("Deleted Successfully")

        elif '0':
            exit()
    except Exception:
        print("Error Encountered")


while 1:
    if selection == '1':
        insert()
    elif selection == '2':
        read()
    elif selection == '3':
        update()
    elif selection == '4':
        delete()
    elif selection == '0':
        exit()
    else:
        print("Wrong selection!")


'''def findNum():
    try:
        high = int('Enter a high value:  ')
        low = int('Enter a low value: ')

        db.stocks.find({"50-Day Simple Moving Average": {"$gt": low, "$lt": high}})

    except Exception, e:
        print str(e)'''
